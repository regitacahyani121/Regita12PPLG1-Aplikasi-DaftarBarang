<!DOCTYPE html>
<html>
    <head><title>Data Daftar Barang Toko Regita</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
       
          <div class="header-title">
              <a href="index.php">Data Daftar Barang Toko Regita</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Barang</a></li>
      
          </ul>
          <div class="konten">
         
            <h1>Selamat datang di halaman Toko</h1>
            <p>Dengan adanya website daftar barang ini mempermudah dalam pencarian data daftar barang</p>
          </div>
          <div class="fotter">
            <p>Copyright 2025@regitaPPLG</p>
          </div>
    </body>
</html>