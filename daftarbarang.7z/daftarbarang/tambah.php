<?php
$conn = mysqli_connect("localhost", "root","","barang");

if(isset($_POST["submit"])){
//var_dump($_POST ["barang"]);
$nama = htmlspecialchars ($_POST ["nama"]);
$harga = htmlspecialchars ($_POST ["harga"]);
$stok = htmlspecialchars ($_POST ["stok"]);
$cari = "INSERT INTO daftar_isi
        VALUES ('', '$nama', '$harga' , '$stok')";
        mysqli_query ( $conn,$cari);
        if (mysqli_affected_rows($conn) >0)
        echo "<script>
        alert ('Data Berhasil Ditambahkan');
        document.location.href='data.php';     
        </script>
        ";

        
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title><link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

        <div class="header-title">
            <a href="index.php"> Data Daftar Barang Toko Regita</a>
        </div>
    </div>
	<ul class="menu">
    <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Barang</a></li>
      
      
    </ul>
    <h1>Data Daftar Barang Toko Regita</h1>
    <h2>Tambah Barang</h2>
    <form action="" method="post">
        <label for="">nama</label>
        <input type="text" name="nama" id="nama" required>
        <br>
        <label for="">harga</label>
        <input type="text" name="harga" id="harga" required>
        <br>
        <label for="">stok</label>
        <input type="text"  name="stok" id=" stok"  required>
        <br>
        
        <button type="submit" name="submit">Tambahkan</button>

    </form>
    <div class="fotter">
        <P>Copyright 2025@regitaPPLG</P> 
 
     </div>    
</body>
</html> 