<?php
$conn = mysqli_connect ("localhost", "root", "", "barang");

function tambah ($cari) {
    global $conn;
    $nama =  htmlspecialchars($_POST["nama"]);
    $harga =  htmlspecialchars($_POST["harga"]);
    $stok =  htmlspecialchars($_POST["stok"]);
    
    $cari="INSERT INTO barang VALUES ('','$nama','$harga', '$stok' )";
    mysqli_query ($conn,$cari);

    return mysqli_affected_rows ($conn);
}

function edit ($no){
    global $conn;
    $nama =  htmlspecialchars($_POST["nama"]);
    $harga =  htmlspecialchars($_POST["harga"]);
    $stok =  htmlspecialchars($_POST["stok"]);

    //$query= "UPDATE barang VALUES ('','$nama','$harga', '$stok' )";
    
mysqli_query ($conn, $query);
return mysqli_affected_rows ($conn);
}

function hapus ($no){
    global $conn;
    mysqli_query ($conn, "DELETE FROM daftar_isi WHERE no = $no");
    return mysqli_affected_rows ($conn);


}



?>