<?php
include 'function.php';
$no = $_GET ["no"];
$cari = mysqli_query ($conn, "SELECT*FROM daftar_isi WHERE no = $no");
if (isset ($_POST ["submit"])){
   
    // var_dump($_POST);
  
    $nama =  htmlspecialchars($_POST["nama"]);
        $harga =  htmlspecialchars($_POST["harga"]);
        
        $stok =  htmlspecialchars($_POST["stok"]);
        
       
     

    //$query= "INSERT INTO barang VALUES ('', '$nama', '$harga', '$stok')";
    $cari="UPDATE daftar_isi SET
          
           nama ='$nama',
           harga ='$harga',
           stok ='$stok'
           
            WHERE no=$no";
mysqli_query ($conn, $cari);

//var_dump(mysqli_affected_rows ($conn));
if (mysqli_affected_rows ($conn)>0){
    echo "<script>
    alert ('Data berhasil diedit');
    document.location.href='data.php';
    </script>
    ";

}else{
    echo "<script>
    alert ('Data berhasil diedit');
    document.location.href='data.php';
    </script>
    ";
}


}
?>
<!doctype html>
<html>
    <head><title>Data Daftar Barang Toko Regita</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
       
          <div class="header-title">
              <a href="index.php">Data Barang Toko Regita</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Barang</a></li>
       
      
          </ul>
          <div class="konten">
       <h1>Edit Barang</h1>
       <?php
       while($data=mysqli_fetch_assoc ($cari)):
       ?>
       <form action=""method="POST">
       
       <label for="">nama</label>
       <input type="text"name="nama" id= required VALUE="<?php echo $data ["nama"]; ?>">
       <br>
       <label for="">harga</label>
       <input type="text"name="harga" id= required VALUE="<?php echo $data ["harga"]; ?>">
       <br>
       <label for="">stok</label>
       <input type="text"name="stok" id= required VALUE="<?php echo $data ["stok"]; ?>">
       <br>
       
       
       <button type="submit" name="submit">Kirim Edit Data</button>
       </form>
       <?php
       endwhile;
       ?>
       </div>

       <div class="fotter">
            <p>Copyright 2025@regitaPPLG</p>
        </div>

</body>
</html>